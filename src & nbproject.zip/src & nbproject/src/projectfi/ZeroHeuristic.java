/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectfi;

/**
 *
 * @author Dell
 */


/**
 * A trivial admissible heuristic that always returns zero.
 * This is the simplest heuristic estimate - it always returns zero, 
 * and hence is also 100% useless as a heuristic.
 * 
 * Notably, using this heuristic with A* causes it to function exactly
 * the same as a Uniform Cost Search, hence no separate implementation
 * of UCS is required.
 * @author lackofcheese
 * @param <S> the type of state used.
 */
public class ZeroHeuristic implements Heuristic {
	/**
	 * Returns an estimate (zero) of the cost to reach the goal
	 * from the given state.
	 * @param s the state.
	 * @return always estimates the cost as zero.
	 */
	public double estimate(State s) {
		return 0;
	}
}
