/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tied;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;



    public class Connect {
    
    public static Connection connect() {
        try {
            Class.forName("org.sqlite.JDBC");
                 Connection con=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Dell\\Documents\\NetBeansProjects\\TIED\\src\\tied\\TIED-DB.sqlite");
                    //JOptionPane.showMessageDialog(null,"connected");
                    return con;
            }
            catch (Exception e){
          
        //JOptionPane.showMessageDialog(null,"cant connect to database:");  
        }
            return null;
    }
    public static void main (String [] args){
       Connect.connect();
    }

    PreparedStatement prepareStatement(String query2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Connect dbConn() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
