DROP TABLE IF EXISTS "Empoyeeinfo";
CREATE TABLE "Empoyeeinfo" ("Empoyeeid" VARCHAR PRIMARY KEY  NOT NULL , "name" TEXT, "surname" TEXT, "age" TEXT, "image" BLOB, "gander" TEXT);
DROP TABLE IF EXISTS "Users";
CREATE TABLE "Users" ("UserID" INTEGER PRIMARY KEY  NOT NULL  UNIQUE , "username" VARCHAR NOT NULL  UNIQUE , "password" VARCHAR NOT NULL , "EmailID" VARCHAR NOT NULL  UNIQUE , "image" BLOB);
INSERT INTO "Users" VALUES(1,'Hamdiya','123456','hamdiyadeaj.hd@gmail.com',NULL);
DROP TABLE IF EXISTS "listImageDecrypt";
CREATE TABLE listImageDecrypt(
  ImageID INTEGER  PRIMARY KEY  NOT NULL,
  ImageName BLOB  NOT NULL,
  Date DATE NOT NULL,
  Comment VARCHAR,
   UserID INTEGER unique,
foreign key ( UserID) references Users ( UserID)
);
DROP TABLE IF EXISTS "listImageEncrypt";
CREATE TABLE listImageEncrypt(
  ImageID INTEGER  PRIMARY KEY  NOT NULL,
  ImageName BLOB  NOT NULL,
  Date DATE NOT NULL,
  Comment VARCHAR,
   UserID INTEGER unique,
foreign key ( UserID) references Users ( UserID)
);
DROP TABLE IF EXISTS "listTextDecrypt";
CREATE TABLE listTextDecrypt(
  TextID INTEGER  PRIMARY KEY  NOT NULL,
  TextName BLOB  NOT NULL,
  Date DATE NOT NULL,
  Comment VARCHAR,
   UserID INTEGER unique,
foreign key ( UserID) references Users ( UserID)
);
INSERT INTO "listTextDecrypt" VALUES(1,'hhh.txt','5/2/16','thgrfsedw',1);
DROP TABLE IF EXISTS "listTextEncrypt";
CREATE TABLE listTextEncrypt(
  TextID INTEGER  PRIMARY KEY  NOT NULL,
  TextName BLOB  NOT NULL,
  Date DATE NOT NULL,
  Comment VARCHAR,
   UserID INTEGER unique,
foreign key ( UserID) references Users ( UserID)
);
DROP TABLE IF EXISTS "pictures";
CREATE TABLE "pictures" ("name" VARCHAR PRIMARY KEY  NOT NULL  UNIQUE , "description" VARCHAR, "image" BLOB NOT NULL  UNIQUE );
